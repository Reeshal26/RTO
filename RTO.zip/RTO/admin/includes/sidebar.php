<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				
					
					
					<ul>
						<!--<li><a href="create-room.php">Add a Room</a></li>-->
						<!--<li><a href="manage-rooms.php">Manage Rooms</a></li>-->
					</ul>
				</li>
				<li><a href="add_vehicles.php"><i class="fa fa-car"></i> vehicles</a></li>
				<li><a href="vehicledetais.php"><i class="fa fa-book"></i>vehicledetails</a></li>
				<!--<li><a href="registration.php"><i class="fa fa-user"></i>Student Registration</a></li>-->
				<li><a href="add_police.php"><i class="fa fa-user"></i>police</a></li>
				<li><a href="policedetails.php"><i class="fa fa-users"></i>police details</a></li>
				<li><a href="add_law.php"><i class="fa fa-book"></i>law's</a></li>
				<li><a href="lawdetails.php"><i class="fa fa-book"></i>law's details</a></li>
				
				<li><a href="fineview.php"><i class="fa fa-file"></i>fine details</a></li>

			
		</nav>