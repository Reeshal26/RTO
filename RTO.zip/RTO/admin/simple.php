<?php
	// Account details
	$username = "thikkar40@gmail.com";
	$hash = "7bbe78b61f527fdf0c0f5f117ebd5c35ede1882b9149f275a532ec15b0778978";
	$apiKey = "RgVS1owcGsM-X2N4pz9DKPIGFeEQGpDF1bRYmybOlJ";
	$a='918970093125';
	// Message details
	$numbers = array($a);
	$sender = urlencode('TXTLCL');
	$message = rawurlencode('This is your message');
 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	// Process your response here
	echo $response;
?>