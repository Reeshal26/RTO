<?php	
echo "hello";
include('includes/config.php');
echo "hello12";
$ret="select * from vehicles";

echo $ret;

$stmt= $mysqli->($ret) ;
echo $stmt;

//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	
	  	 echo $cnt;;

 echo $row->vehicles_no;
 echo $row->owner_name;
 echo $row->mobile_number;
}?>
